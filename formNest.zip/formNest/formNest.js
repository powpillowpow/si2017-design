$(".more").click(moreMentors);
$(".appButton").click(form);
$(".buttonSub").click(sent);
$(".name input").blur(checkEmpty1);
$(".email input").blur(checkEmpty2);
$(".phone input").blur(checkEmpty3);
$(".employees input").blur(checkEmpty4);
$(".mentors input").blur(checkEmpty5);
$(".learn textarea").blur(checkEmpty6);

function moreMentors(){
    $("<p><input type='text' name='phone' class='morMentors'></p>").insertBefore(".more");
};


function form(){
    $(".intro").fadeIn(300);
    $(".generalInfo").delay(300).fadeIn(300);
    $(".specifics").delay(600).fadeIn(300);
    $(".appButtonSub").delay(900).fadeIn(300);
    $(".end").fadeOut(300);
}

function sent(){
    if($(".warning1").is(":hidden") && $(".warning2").is(":hidden") && $(".warning3").is(":hidden") && $(".warning4").is(":hidden") && $(".warning5").is(":hidden") && $(".warning6").is(":hidden")){
        console.log("deu");
        $(".intro").fadeOut(300);
        $(".generalInfo").fadeOut(300);
        $(".specifics").fadeOut(300);
        $(".appButtonSub").fadeOut(300);
        $(".cantSend").fadeOut(300);
        $(".end").fadeIn(300);
    }
    
    else{
        $(".cantSend").fadeIn(300);
    }
}


function checkEmpty1(){
    if($(".name input").val().length === 0){
        $(".warning1").fadeIn(300);
    }
    
    else{
        $(".warning1").fadeOut(300);
    }
    
}

function checkEmpty2(){
    if($(this).val().length === 0){
        $(".warning2").fadeIn(300);
    }
    
    else{
        $(".warning2").fadeOut(300);
    }
    
}

function checkEmpty3(){
    if($(this).val().length === 0){
        $(".warning3").fadeIn(300);
    }
    
    else{
        $(".warning3").fadeOut(300);
    }
    
}

function checkEmpty4(){
    if($(this).val().length === 0){
        $(".warning4").fadeIn(300);
    }
    
    else{
        $(".warning4").fadeOut(300);
    }
    
}

function checkEmpty5(){
    if($(this).val().length === 0){
        $(".warning5").fadeIn(300);
    }
    
    else{
        $(".warning5").fadeOut(300);
    }
    
}

function checkEmpty6(){
    if($(this).val().length === 0){
        $(".warning6").fadeIn(300);
    }
    
    else{
        $(".warning6").fadeOut(300);
    }
    
}